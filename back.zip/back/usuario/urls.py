from django.urls import path
from usuario.views import home 
from usuario.views import responderQuestoes, verTrilha, novoProfessor, novoAluno, novaQuestao, novaTrilha
urlpatterns = [
    path('cadastrar_aluno/', novoAluno, name="novoAluno"),
    path('cadastrar_professor/', novoProfessor, name="novoProfessor"),
    path('cadastrar_questao/', novaQuestao, name="novaQuestao"),
    path('cadastrar_trilha/', novaTrilha, name="novaTrilha"),
    path('consultar_trilhas/', verTrilha, name="novaTrilha"),
    path('responder_questoes/<str:trilha>/', responderQuestoes, name="responderQuestoes")
]
