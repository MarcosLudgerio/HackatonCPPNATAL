from django.shortcuts import render
from questoes.models import Questao, Trilha
from .models import Aluno
from .forms import FormAluno, FormProfessor
from questoes.forms import formQuestao, formTrilha
from django.contrib.auth.decorators import login_required

# Create your views here.
def home(request):
    return render(request, 'index.html')


@login_required
def novoAluno(request):
    form = FormAluno(request.POST, None)
    return render(request, 'adicionarAluno.html', {'form':form})

@login_required
def novoProfessor(request):
    form = FormProfessor(request.POST, None)
    return render(request, 'adicionarProfessor.html', {'form':form})

@login_required
def novaTrilha(request):
    form = formTrilha
    return render(request,'adicionarTrilha.html',{'form':form})

@login_required
def novaQuestao(request):
    form = formQuestao(request.POST, None)
    return render(request,'adicionarQuestao.html',{'form':form })
 
@login_required
def verTrilha(request):
    alunosTrilha = Aluno.objects.all()
    return render(request,'racking.html',{'trilhas':alunosTrilha})

def responderQuestoes(request, trilha):
    questoes = Questao.objects.filter(atividade=trilha)
    return render(request,'questoes.html',{'questoes':questoes})
