from django.contrib import admin
from .models import Aluno
from .models import Professor
from questoes.models import Questao
# Register your models here.


class listaProfessores(admin.ModelAdmin):
    list_display = ['nome', 'email','login']
    search_fields = ['nome','email']

class listaAlunos(admin.ModelAdmin):
    list_display = ['nome', 'email','login']
    search_fields = ['nome','email']

class listaAlunos(admin.ModelAdmin):
    list_display = ['codigo']
    search_fields = ['codigo']


admin.site.register(Aluno)
admin.site.register(Professor)
admin.site.register(Questao)