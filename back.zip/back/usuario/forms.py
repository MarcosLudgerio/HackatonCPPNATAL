from django.forms import ModelForm
from .models import Aluno, Professor

class FormProfessor(ModelForm):
    class Meta:
        model = Professor
        fields = ['nome','email','login','senha','contato']
    
class FormAluno(ModelForm):
    class Meta:
        model = Aluno
        fields = ['nome','email','login','senha','contato']