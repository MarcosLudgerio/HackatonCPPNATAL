from django.db import models

# Create your models here.
class Professor(models.Model):
    nome = models.CharField('Nome completo', max_length=100,null=False,blank=False)
    email = models.CharField('E-mail', max_length=100,null=False,blank=False)
    contato = models.CharField('Contato', max_length=100,null=False,blank=False)
    login = models.CharField('Login', max_length=100,null=False,blank=False)
    senha = models.CharField('Senha', max_length=100,null=False,blank=False)
    atividade = models.CharField('Trilha', max_length=100,null=True,blank=True)    
    
    def __str__(self):
        return self.nome
    
    class Meta:
        verbose_name = 'Professor'
        verbose_name_plural = 'Professores'
        ordering = ['nome']

class Aluno(models.Model):
    nome = models.CharField('Nome completo', max_length=100,null=False,blank=False)
    email = models.CharField('E-mail', max_length=100,null=False,blank=False)
    contato = models.CharField('Contato', max_length=100,null=False,blank=False)
    login = models.CharField('Login', max_length=100,null=False,blank=False)
    senha = models.CharField('Senha', max_length=100,null=False,blank=False)
    score = models.IntegerField()

    def __str__(self):
        return self.nome
    
    class Meta:
        verbose_name = 'Aluno'
        verbose_name_plural = 'Alunos'
        ordering = ['nome']