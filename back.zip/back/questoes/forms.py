from django.forms import ModelForm
from .models import Questao, Trilha

class formQuestao(ModelForm):
    class Meta:
        model = Questao
        fields = ['enunciado','a','b','c','d','correta','atividade']

class formTrilha(ModelForm):
    class Meta:
        model = Trilha
        fields = ['nome','texto','img']
