from django.apps import AppConfig


class QuestoesConfig(AppConfig):
    name = 'questoes'
