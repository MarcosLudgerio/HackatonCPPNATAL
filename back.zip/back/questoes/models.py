from django.db import models

# Create your models here.
class Questao(models.Model):
    codigo = models.CharField('Código', max_length=100,null=False,blank=False, unique=True)
    enunciado = models.TextField('Enunciado',max_length=1000)
    a = models.CharField('A', max_length=100,null=False,blank=False)
    b = models.CharField('B', max_length=100,null=False,blank=False)
    c = models.CharField('C', max_length=100,null=False,blank=False)
    d = models.CharField('D', max_length=100,null=False,blank=False)
    atividade = models.CharField('Trilha', max_length=100,null=True,blank=True) 
    correta = models.CharField('Correta', max_length=100,null=False,blank=False)
   
    def __str__(self):
        return self.codigo
    
    class Meta:
        verbose_name = 'Questão'
        verbose_name_plural = 'Questões'
        ordering = ['codigo']

class Trilha(models.Model):
    nome = models.CharField('nome', max_length=100,null=False,blank=False, unique=True)
    texto = models.TextField('Enunciado',max_length=1000)
    img = models.FileField(upload_to="media")
    codigoTrilha = models.IntegerField(default=0, unique=True)
    pontuacao = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return self.nome
    
    class Meta:
        verbose_name = 'Trilha'
        verbose_name_plural = 'Trilhas'
        ordering = ['nome']
    
    